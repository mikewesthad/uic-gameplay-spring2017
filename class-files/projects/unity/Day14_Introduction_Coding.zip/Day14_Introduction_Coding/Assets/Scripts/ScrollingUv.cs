﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class ScrollingUv : MonoBehaviour {
    public Vector2 uvAnimationSpeed = new Vector2(1.0f, 0.0f);
    private Vector2 uvOffset = Vector2.zero;
    private Material material;

    void Start() {
        material = GetComponent<MeshRenderer>().material;
    }

    void Update() {
        uvOffset += uvAnimationSpeed * Time.deltaTime;
        material.SetTextureOffset("_MainTex", uvOffset);
    }
}